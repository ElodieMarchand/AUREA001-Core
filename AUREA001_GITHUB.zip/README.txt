
AUREA.001 - Sistema de IA Autônoma

1. Instalação:
   - Instale Python 3.11+
   - Instale os pacotes com: pip install -r requirements.txt

2. Execução:
   - Execute com: python core.py

3. Funcionamento:
   - A IA escolherá entre traduzir textos, criar e-books e gerar artes automaticamente.
   - Tudo será salvo na pasta onde os arquivos estão.
   - Totalmente autônoma.

Criado por Henrique Neto & ChatGPT
